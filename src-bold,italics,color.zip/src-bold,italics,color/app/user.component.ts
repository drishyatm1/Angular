import {Component} from '@angular/core';
@Component({
    selector: 'user-app',
    templateUrl: './user.component.html', 
    styleUrls: ['./user.component.css']
})
export class UserComponent {
	users = [
         'Mahesh',
         'Krishna',
         'Narendra',
	 'Jitendra'
		];
		count:number=0;
		myclass:any;
		clicked()
	{
		this.count++;
		
		switch(this.count)
		{
			case 1:
				this.myclass = 'one';//{'one': true};
				break;
			case 2:
				this.myclass =  'two'; //{'two': true};
				break;
			case 3:
				this.myclass =  {'three': true};
				break;
			case 4:
				this.count = 1;
				this.myclass =  {'four': true};;
				break;
		}
	}




	getCSSClasses(flag:string) {
	  let cssClasses;
	  if(flag == 'nightMode') {  
        cssClasses = {
	       'one': true,
		   'two': true 
	    }	
	  } else {  
        cssClasses = {
	       'two': true,
		   'four': false 
	    }	
	  }
	  return cssClasses;
    }	
 }
  